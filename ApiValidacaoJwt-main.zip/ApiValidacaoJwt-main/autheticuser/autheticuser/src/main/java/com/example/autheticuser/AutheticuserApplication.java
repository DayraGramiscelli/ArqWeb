package com.example.autheticuser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutheticuserApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutheticuserApplication.class, args);
	}

}
